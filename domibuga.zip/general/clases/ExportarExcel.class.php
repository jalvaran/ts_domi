<?php
if(file_exists("../../modelo/php_conexion.php")){
    include_once("../../modelo/php_conexion.php");
}

class ExcelExport extends conexion{
   
    
    /**
     * Fin Clase
     */
}
