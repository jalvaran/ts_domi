<?php 

header("location: modulos/main/main.php");
?>