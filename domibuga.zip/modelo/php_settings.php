<?php
/* 
 * Aqui se establecen los datos de conexion a la base de datos
 */

const HOST="localhost", USER="techno",PW="techno",DB="ts_domi"; //para uso 

?>